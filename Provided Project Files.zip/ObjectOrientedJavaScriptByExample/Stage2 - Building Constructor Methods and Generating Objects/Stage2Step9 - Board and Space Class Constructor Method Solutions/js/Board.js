class Board {
    constructor() {
        this.rows = 6;
        this.columns = 7;
        this.spaces = [];
    }
}
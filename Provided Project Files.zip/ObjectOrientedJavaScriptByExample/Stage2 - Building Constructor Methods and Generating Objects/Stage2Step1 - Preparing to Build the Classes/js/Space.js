class Space {
    
}